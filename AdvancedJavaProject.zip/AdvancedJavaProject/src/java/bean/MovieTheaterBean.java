/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import ejb.MovieTheaterEJB;
import entity.Movies;
import entity.Namedescription;
import entity.Reservation;
import entity.Theaters;
import entity.Zips;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 *
 * @author Logan
 */
@Named(value = "movieTheaterBean")
@SessionScoped
public class MovieTheaterBean implements Serializable {

    private Movies movie = new Movies();
    private Namedescription nameDescription = new Namedescription();
    private Reservation reservation = new Reservation();
    private Theaters theater = new Theaters();
    private Zips zip = new Zips();

    private String zipcode = "";
    private String zipcodeValidString = "";
    private String creditCardNumber = "";
    private String creditCardValidString = "";
    private String numOfSeats = "";
    private String numOfSeatsValidString = "";

    public String getNumOfSeatsValidString() {
        return numOfSeatsValidString;
    }

    public void setNumOfSeatsValidString(String numOfSeatsValidString) {
        this.numOfSeatsValidString = numOfSeatsValidString;
    }
    

    public String getNumOfSeats() {
        return numOfSeats;
    }

    public void setNumOfSeats(String numOfSeats) {
        this.numOfSeats = numOfSeats;
    }

    public void setCreditCardNumber(String creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }

    public String getCreditCardNumber() {
        return creditCardNumber;
    }

    public String getCreditCardValidString() {
        return creditCardValidString;
    }

    public String getZipcodeValidString() {
        return zipcodeValidString;
    }

    public void setZipcodeValidString(String zipcodeValidString) {
        this.zipcodeValidString = zipcodeValidString;
    }

    public Reservation getReservation() {
        return reservation;
    }

    public void setReservation(Reservation reservation) {
        this.reservation = reservation;
    }

    public Theaters getTheater() {
        return theater;
    }

    public void setTheater(Theaters theater) {
        this.theater = theater;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    @EJB
    private MovieTheaterEJB movieTheaterEJB;

    public MovieTheaterBean() {
    }

    public String goToAllTheaters() {
        return "AllTheaters.xhtml";
    }

    public String goToMovies() {
        return "Movies.xhtml";
    }

    public String goToMoviesForTheater(Theaters theater) {
        this.theater = theater;
        System.out.println("hiHoHiHo");
        return "MoviesForTheater.xhtml";
    }

    public String goToMoviesForTheater() {
        return "MoviesForTheater.xhtml";
    }

    public String goToSearchNoResults() {
        return "Search[noResults].xhtml";
    }

    public String goToSearchWithResults() {
        
        return "Search[withResults].xhtml";
    }

    public String goToHome() {
        return "Home.xhtml";
    }

    public String goToNumberOfSeats() {
        return "NumberOfSeats.xhtml";
    }

    public String goToNumberOfSeats(Movies movie) {
        this.movie = movie;
        return "NumberOfSeats.xhtml";
    }

    public String goToReservation(Movies movie) {
        this.movie = movie;
        return "Reservation.xhtml";
    }

    public String goToReservation() {
        return "Reservation.xhtml";
    }

    public String goToReservationConfirmed() {
        return "ReservationConfirmed.xhtml";
    }

    public String endOfMovies() {
        return goToHome();
    }

    public String endOfAllTheaters(Theaters theater) {
        this.theater = theater;
        return goToMoviesForTheater();
    }

    public String validateZip() {

        if (zipcode.length() != 5) {
            zipcodeValidString = "Invalid Zipcode Format";
            return goToSearchNoResults();
        }
        for (int i = 0; i < zipcode.length(); i++) {
            if (!Character.isDigit(zipcode.charAt(i))) {
                zipcodeValidString = "Invalid Zipcode Format";
                return goToSearchNoResults();
            }
        }

        return goToSearchWithResults();
    }

    public boolean validateCreditCard() {
        String num = reservation.getCreditcardnumber();
        if (num.length() != 16) {
            creditCardValidString = "Invalid Credit Card number";
            return false;
        }
        for (int i = 0; i < num.length(); i++) {
            if (!Character.isDigit(num.charAt(i))) {
                creditCardValidString = "Invalid Credit Card number";
                return false;
            }
        }
        return true;
    }

    public String submitReservation() {
        if (!validateCreditCard()) {
            return goToReservation();
        }

        movieTheaterEJB.persist(reservation);
        return goToReservationConfirmed();
    }

    public String endOfSearchNoResults(Zips zip) {
        this.zip = zip;
        return goToSearchWithResults();
    }

    public String endOfSearchWithResults(Theaters theater) {
        this.theater = theater;
        return goToMoviesForTheater();
    }

    public String endOfMoviesForTheater(Movies movie) {
        this.movie = movie;
        return goToReservation();
    }

    public List<Namedescription> getAllMoviesList() {

        List<Namedescription> list = movieTheaterEJB.getAllMovies();

        return list;
    }

    public List<Theaters> getAllTheatersList() {

        List<Theaters> list = movieTheaterEJB.getAllTheaters();

        return list;
    }

    public List<Theaters> getTheatersByZip() {

        Zips zippy = getZipByZipcode();

        List<Theaters> listy = movieTheaterEJB.getTheatersByZip(zippy);

        return listy;
    }

    public Zips getZipByZipcode() {
        zip = movieTheaterEJB.getZipByZipcode(zipcode);
        return zip;
    }

    public List<Movies> getMoviesByTheater() {
        return movieTheaterEJB.getMoviesByTheater(theater);
    }

    public void gatherReservationInfo() {
        reservation.setMoviename(movie.getNamedescriptionFk().getMovietitle());
        reservation.setTheatername(theater.getName());
        reservation.setTimex(movie.getTime());
        reservation.setZipx(zipcode);
        reservation.setTheateraddress(theater.getAddress());
        reservation.setSeatnum(numOfSeats);
    }

    public String confirmSeats() {
        for (int i = 0; i < numOfSeats.length(); i++) {
            if (!Character.isDigit(numOfSeats.charAt(i))) {
                numOfSeatsValidString = "Invalid";
                return goToNumberOfSeats();
            }
        }
        return goToReservation();
    }
    public String getPrice(){
        Integer seatInt = Integer.parseInt(numOfSeats);
        Integer price = seatInt * 10;
        return price.toString();
    }

}
