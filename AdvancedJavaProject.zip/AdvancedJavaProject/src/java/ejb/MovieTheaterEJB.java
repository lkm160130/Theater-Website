/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import static com.sun.activation.registries.LogSupport.log;
import entity.Movies;
import entity.Namedescription;
import entity.Theaters;
import entity.Zips;
import static java.lang.Math.log;
import static java.lang.StrictMath.log;
import static java.rmi.server.LogStream.log;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import javax.ejb.Stateful;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.validation.ConstraintViolationException;

/**
 *
 * @author Logan
 */
@Stateless
public class MovieTheaterEJB {
@PersistenceContext(unitName = "AdvancedJavaProjectPU")
    private EntityManager em;
    
    
 public List<Namedescription> getAllMovies()
    {
        
        List<Namedescription> list = em.createNamedQuery("Namedescription.findAll", Namedescription.class)
                 .getResultList();
        
        return list;
    }
 
    public Zips getZipByZipcode(String zipcode){
       
        try{
        Zips zip = new Zips();
        zip = em.createNamedQuery("Zips.findByZipcode", Zips.class)
                 .setParameter("zipcode", zipcode)
                .getSingleResult();
        return zip;
        }
        catch(NoResultException e){
            
            return new Zips();
        }
        
    }
    public List<Theaters> getTheatersByZip(Zips zip){
        
        try{
            List<Theaters> list = new ArrayList();
        list = em.createNamedQuery("Theaters.findByZipIdFk", Theaters.class)
                .setParameter("zipidFk", zip)
                 .getResultList();
        return list;
        }
        catch(NoResultException e){
            List<Theaters> list = new ArrayList();
            return list;
                    
        }
    }

    public List<Movies> getMoviesByTheater(Theaters theater) {
       try{
            List<Movies> list = new ArrayList();
        list = em.createNamedQuery("Movies.findByTheaterIdFk", Movies.class)
                .setParameter("theateridFk", theater)
                 .getResultList();
        return list;
        }
        catch(NoResultException e){
            List<Movies> list = new ArrayList();
            return list;
                    
        }
    }

    public void persist(Object object) {
        try{
        em.persist(object);
        }
        catch (ConstraintViolationException e) {
       System.out.println("apple" + e.getConstraintViolations().toString());
    }
    }

    public List<Theaters> getAllTheaters() {
          List<Theaters> list = em.createNamedQuery("Theaters.findAll", Theaters.class)
                 .getResultList();
        
        return list;
    }

    
}
